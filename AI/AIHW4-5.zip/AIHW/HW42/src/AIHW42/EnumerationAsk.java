package AIHW42;

import help.Util;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EnumerationAsk {

    BayesNetwork bn;

    public EnumerationAsk() {
    }

    public double[] enumerationAsk(RandomVariable X, List<RandomVariable> evidences, BayesNetwork b) {
        bn = b;
        double[] Q = new double[2];
        X.value = 1;
        evidences.add(X);
        Q[0] = enumerateAll(bn.getVariablesInTopologicalOrder(), evidences);
        evidences.remove(X);
        X.value = 0;
        evidences.add(X);
        Q[1] = enumerateAll(bn.getVariablesInTopologicalOrder(), evidences);
        evidences.remove(X);
        double normalizer = Q[0] + Q[1];
        Q[0] = Q[0] / normalizer;
        Q[1] = Q[1] / normalizer;
        return Q;
    }

    protected double enumerateAll(List<RandomVariable> vars, List<RandomVariable> es) {
        if (0 == vars.size()) {
            return 1;
        }
        RandomVariable Y = Util.first(vars);
        if (es.contains(Y)) {
            double d = posteriorProb(Y, es);
            double d0 = enumerateAll(Util.rest(vars), es);
            System.out.println();
            System.out.println(Y.name + "=" + Y.value);
            System.out.println(d + "*" + d0 + "=" + d * d0);
            System.out.println();
            return d * d0;
        }
        double sum = 0;
        Y.value = 1;
        es.add(Y);
        double d1 = posteriorProb(Y, es);
        double d2 = enumerateAll(Util.rest(vars), es);
        System.out.println();
        System.out.println(Y.name + "=" + Y.value);
        System.out.println(d1 + "*" + d2 + "=" + d1 * d2);
        System.out.println(sum + "+" + d1 * d2 + "=" + (sum + (d1 * d2)));
        System.out.println();
        sum += d1 * d2;
        Y.value = 0;
        double d3 = posteriorProb(Y, es);
        double d4 = enumerateAll(Util.rest(vars), es);
        System.out.println();
        System.out.println(Y.name + "=" + Y.value);
        System.out.println(d3 + "*" + d4 + "=" + d3 * d4);
        System.out.println(sum + "+" + d3 * d4 + "=" + (sum + (d3 * d4)));
        System.out.println();
        sum += d3 * d4;
        es.remove(Y);
        return sum;
    }

    public double posteriorProb(RandomVariable v, List<RandomVariable> e) {
        Cpt cpt = bn.varToNodeMap.get(v).getCPT();
        Set<Node> parentNodes = bn.varToNodeMap.get(v).getParents();
        List<RandomVariable> parentRvs = new ArrayList<>();
        for (Node n : parentNodes) {
            parentRvs.add(n.getRandomVariable());
        }
        String s = "0";
        for (RandomVariable pr : parentRvs) {
            if (e.contains(pr)) {
                s = s + pr.value;
            }
        }
        int decimalValue = Integer.parseInt(s, 2);
        double pprob = cpt.map.get(decimalValue);
        //cpt has the values for true
        if (v.value == 1) {
            return pprob;
        } else {
            return (1 - pprob);
        }
    }
}
