/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW41;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author B
 */
public class Node {

    private RandomVariable variable = null;
    private Set<Node> parents = null;
    private Set<Node> children = null;
    private Cpt cpt = null;

    public Node(RandomVariable var, double[] distribution) {
        //double[] values={false,true}={0,1}
        this(var, distribution, (List<Node>) null);
    }

    public Node(RandomVariable var, List<Node> parents) {
        this.variable = var;
        this.parents = new LinkedHashSet<>();
        if (null != parents) {
            for (Node p : parents) {
                ((Node) p).addChild(this);
                this.parents.add(p);
            }
        }
        this.parents = Collections.unmodifiableSet(this.parents);
        this.children = Collections.unmodifiableSet(new LinkedHashSet<>());
    }

    public Node(RandomVariable var, double[] values, List<Node> parents) {
        //double {leak value, qt}
        this(var, parents);
        RandomVariable[] conditionedOn = new RandomVariable[getParents().size()];
        int i = 0;
        for (Node p : getParents()) {
            conditionedOn[i++] = p.getRandomVariable();
        }
        cpt = new Cpt(var, values, conditionedOn);
    }

    //
    // START-Node
    public RandomVariable getRandomVariable() {
        return variable;
    }

    public boolean isRoot() {
        return 0 == getParents().size();
    }

    public final Set<Node> getParents() {
        return parents;
    }

    public Set<Node> getChildren() {
        return children;
    }

    public Cpt getCPT() {
        return cpt;
    }

    // END-Node
    //
    @Override
    public boolean equals(Object o) {
        if (null == o) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if (o instanceof Node) {
            Node n = (Node) o;
            return getRandomVariable().equals(n.getRandomVariable());
        }
        return false;
    }


    protected void addChild(Node childNode) {
        children = new LinkedHashSet<>(children);
        children.add(childNode);
        children = Collections.unmodifiableSet(children);
    }
}
