/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW41;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author B
 */
public class AIHW41 {

    public static Graph graph;
    public static int numberOfVertices;
    public static int numberOfTypes;
    public static double[] key1Prob = new double[2]; //{true, false},{1,0}
    public static double[] key2Prob = new double[2]; //{true, false},{1,0}
    public static double[] brcProb = new double[]{0.1, 0.9};//{true, false},{1,0}

    public static void main(String[] args) throws FileNotFoundException {
        readGraph();
        //write graph
        System.out.println(numberOfVertices + "  # of vertices");
        System.out.println(numberOfTypes + "  # of key types");
        System.out.println("Edges");
        for (Vertex v : graph.vertexList) {
            for (Edge e : v.edgeList) {
                System.out.println(e.source + " " + e.destination + " " + e.weight);
            }
        }
        System.out.println("Key0 probability= " + key1Prob[0]);
        RandomVariable brcrv = new RandomVariable("brc6");
        Node brcn = new Node(brcrv, brcProb);
        List<Node> kns = new ArrayList<>();
        if (numberOfTypes == 1) {
            kns.add(brcn);
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k0v" + i);
                Node kn = new Node(krv, key1Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l0v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
        }
        if (numberOfTypes == 2) {
            kns.add(brcn);
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k0v" + i);
                Node kn = new Node(krv, key1Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l0v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))
                            & Character.getNumericValue(n.getRandomVariable().name.charAt(1)) == 0) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k1v" + i);
                Node kn = new Node(krv, key2Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l1v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))
                            & Character.getNumericValue(n.getRandomVariable().name.charAt(1)) == 1) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
        }
        BayesNetwork bn = new BayesNetwork(kns);
        System.out.println();
        for (RandomVariable v : bn.variables) {
            System.out.println(v.name + "=" + v.value);
        }
        System.out.println();
        List<RandomVariable> evidences = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        Boolean bool = true;
        System.out.println("q for quit");
        while (bool) {
            System.out.print("evidence name: ");
            String en = input.next();
            if ("q".equals(en)) {
                break;
            }
            System.out.print("evidence value: ");
            int ev = input.nextInt();
            for (RandomVariable rv : bn.variables) {
                if (rv.name.equals(en)) {
                    rv.value = ev;
                    evidences.add(rv);
                }
            }
        }
        EnumerationAsk ea = new EnumerationAsk();
        System.out.println();
        for (RandomVariable v : bn.variables) {
            System.out.println(v.name + "=" + v.value);
        }
        System.out.println();
        System.out.print("query name: ");
        String qn = input.next();
        RandomVariable qv = new RandomVariable(null);
        for (RandomVariable rv : bn.variables) {
            if (rv.name.equals(qn)) {
                qv = rv;
            }
        }
        double[] result = ea.enumerationAsk(qv, evidences, bn);
        System.out.println(result[0] + "," + result[1]);
        System.out.println();
        for (RandomVariable v : bn.variables) {
            System.out.println(v.name + "=" + v.value);
        }
    }

    public static void readGraph() throws FileNotFoundException {
        Scanner inFile;
        File file = new File("graph1.txt");
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        numberOfTypes = inFile.nextInt();
        graph = new Graph(numberOfVertices);
        String s;
        if (inFile.next().equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        if (numberOfTypes == 1) {
            double v;
            double k;
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key1Prob = new double[]{v, k};
        }
        if (numberOfTypes == 2) {
            double v;
            double k;
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key1Prob = new double[]{v, k};
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key2Prob = new double[]{v, k};
        }
    }
}
