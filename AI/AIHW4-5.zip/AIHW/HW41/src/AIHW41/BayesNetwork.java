/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW41;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author B
 */
public class BayesNetwork {

    protected Set<Node> rootNodes = new LinkedHashSet<>();
    protected List<RandomVariable> variables = new ArrayList<>();
    protected Map<RandomVariable, Node> varToNodeMap = new HashMap<>();

    public BayesNetwork(List<Node> rootNodes) {
        for (Node n : rootNodes) {
            this.rootNodes.add(n);
        }
        // Ensure  DAG
        checkIsDAGAndCollectVariablesInTopologicalOrder();
        variables = Collections.unmodifiableList(variables);
    }

    public List<RandomVariable> getVariablesInTopologicalOrder() {
        return variables;
    }

    public Node getNode(RandomVariable rv) {
        return varToNodeMap.get(rv);
    }

    private void checkIsDAGAndCollectVariablesInTopologicalOrder() {

        Set<Node> seenAlready = new HashSet<>();
        Map<Node, List<Node>> incomingEdges = new HashMap<>();
        Set<Node> s = new LinkedHashSet<>();
        for (Node n : this.rootNodes) {
            walkNode(n, seenAlready, incomingEdges, s);
        }
        while (!s.isEmpty()) {
            Node n = s.iterator().next();
            s.remove(n);
            variables.add(n.getRandomVariable());
            varToNodeMap.put(n.getRandomVariable(), n);
            for (Node m : n.getChildren()) {
                List<Node> edges = incomingEdges.get(m);
                edges.remove(n);
                if (edges.isEmpty()) {
                    s.add(m);
                }
            }
        }
        for (List<Node> edges : incomingEdges.values()) {
            if (!edges.isEmpty()) {
                throw new IllegalArgumentException(
                        "Network contains at least one cycle in it, must be a DAG.");
            }
        }
    }

    private void walkNode(Node n, Set<Node> seenAlready,
            Map<Node, List<Node>> incomingEdges, Set<Node> rootNodes) {
        if (!seenAlready.contains(n)) {
            seenAlready.add(n);
            // Check if has no incoming edges
            if (n.isRoot()) {
                rootNodes.add(n);
            }
            incomingEdges.put(n, new ArrayList<>(n.getParents()));
            for (Node c : n.getChildren()) {
                walkNode(c, seenAlready, incomingEdges, rootNodes);
            }
        }
    }
}
