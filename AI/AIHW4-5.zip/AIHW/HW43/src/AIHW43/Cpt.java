/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW43;

import static java.lang.Math.pow;
import java.util.HashMap;

/**
 *
 * @author B
 */
public class Cpt {

    HashMap<Integer, Double> map = new HashMap<>();

    public Cpt(RandomVariable var, double[] values, RandomVariable[] parentRvs) {
        //double {leak value=0.01, qt=0.8}
        //double {nonleak value=0.001, qf=0.9}
        double qf=0.9;
        double nonLeakValue=0.001;
        double leakValue=values[0];
        double qt=values[1];
        int numberOfColumns = parentRvs.length;
        int numberOfEntries= (int) pow(2, numberOfColumns);
        //loop for brc=false
        for (int i = 0; i < numberOfEntries; i++) {
            Double d;
            //brc=false
            if(i==0)
            {
                d=leakValue;
            }
            else if(i>=1 & i<numberOfEntries/2)
            {
                int power=((i)/numberOfColumns)+1;
                d=1-(pow(qt,power)); 
            }
            //brc=true
            else if(i==numberOfEntries/2)
            {
                d=nonLeakValue;
            }
            else
            {
                int power=((i-(numberOfEntries/2))/numberOfColumns)+1;
                d=1-(pow(qf,power));
            }
            //map has the values for true
            map.put(i, d);
        }
        System.out.println();
        System.out.println(var.name);
            for(double v:map.values())
            {
                System.out.print(v+", ");
            }
            System.out.println();
        
    }
}
