/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW43;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 *
 * @author B
 */
public class AIHW43 {

    public static State initialState;
    public static int goalState;
    public static int totalCost = 0, totalDepth = 0;
    public static Graph graph;
    public static int numberOfVertices;
    public static int numberOfTypes;
    public static double[] key1Prob = new double[2]; //{true, false},{1,0}
    public static double[] key2Prob = new double[2]; //{true, false},{1,0}
    public static double[] brcProb = new double[]{0.1, 0.9};//{true, false},{1,0}
    public static BayesNetwork bn;
    public static List<RandomVariable> evidences;

    public static void main(String[] args) throws FileNotFoundException {
        readGraph();
        //write graph
        System.out.println(numberOfVertices + "  # of vertices");
        System.out.println(numberOfTypes + "  # of key types");
        System.out.println("Edges");
        for (Vertex v : graph.vertexList) {
            for (Edge e : v.edgeList) {
                System.out.println(e.source + " " + e.destination + " " + e.weight);
            }
        }
        System.out.println("Key0 probability= " + key1Prob[0]);
        RandomVariable brcrv = new RandomVariable("brc6");
        Node brcn = new Node(brcrv, brcProb);
        List<Node> kns = new ArrayList<>();
        if (numberOfTypes == 1) {
            kns.add(brcn);
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k0v" + i);
                Node kn = new Node(krv, key1Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l0v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
        }
        if (numberOfTypes == 2) {
            kns.add(brcn);
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k0v" + i);
                Node kn = new Node(krv, key1Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l0v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))
                            & Character.getNumericValue(n.getRandomVariable().name.charAt(1)) == 0) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable krv = new RandomVariable("k1v" + i);
                Node kn = new Node(krv, key2Prob);
                kns.add(kn);
            }
            for (int i = 0; i < numberOfVertices; i++) {
                RandomVariable lrv = new RandomVariable("l1v" + i);
                int currentVertex = i;
                int otherVertex;
                ArrayList<Integer> otherVertices = new ArrayList<>();
                otherVertices.add(i);
                for (Edge e : graph.vertexList[currentVertex].edgeList) {
                    if (currentVertex == e.source) {
                        otherVertex = e.destination;
                    } else {
                        otherVertex = e.source;
                    }
                    otherVertices.add(otherVertex);
                }
                List<Node> parents = new ArrayList<>();
                parents.add(brcn);
                for (Node n : kns) {
                    if (otherVertices.contains(Character.getNumericValue(n.getRandomVariable().name.charAt(3)))
                            & Character.getNumericValue(n.getRandomVariable().name.charAt(1)) == 1) {
                        parents.add(n);
                    }
                }
                Node ln = new Node(lrv, new double[]{0.01, 0.8}, parents); //{leakValue, qt}
                System.out.print("parents of ");
                System.out.print(ln.getRandomVariable().name + ": ");
                for (Node n : ln.getParents()) {
                    System.out.print(n.getRandomVariable().name + ", ");
                }
                System.out.println();
            }
        }
        bn = new BayesNetwork(kns);
        System.out.println();
        for (RandomVariable v : bn.variables) {
            System.out.println(v.name + "=" + v.value);
        }
        System.out.println();
        evidences = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        Boolean bool = true;
        System.out.println("q for quit");
        while (bool) {
            System.out.print("evidence name: ");
            String en = input.next();
            if ("q".equals(en)) {
                break;
            }
            System.out.print("evidence value: ");
            int ev = input.nextInt();
            for (RandomVariable rv : bn.variables) {
                if (rv.name.equals(en)) {
                    rv.value = ev;
                    evidences.add(rv);
                }
            }
        }
        Solution sol=uniformCostSearch(initialState);
        System.out.println("path with the least degree of belief that there are locks:");
        for(SearchNode n:sol.path)
        {
           System.out.print(n.state.agentVertex+",");
        }
        System.out.println();
       
    }
    
    
    public static Solution uniformCostSearch(State initialState) {
      
        Solution sol = new Solution();
        ArrayList<Integer> closed = new ArrayList<>();
        PriorityQueue<SearchNode> fringe = new PriorityQueue<>(1, new Comparator<SearchNode>() {
            @Override
            public int compare(SearchNode n0, SearchNode n1) {
                return new Double((n0.cost)).compareTo(n1.cost);
            }
        });
        fringe.add(makeInitialNode(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                sol.failure = true;
                return sol;
            }
            SearchNode n = fringe.remove();
            if (goalTest(goalState, n.state)) {
                //there is a solution
                sol.path = solutionPath(n);
                sol.cutoff = false;
                return sol;
            }
            if (!closed.contains(n.state.agentVertex)) {
                closed.add(n.state.agentVertex);
                fringe.addAll(uniformCostExpand(n));
            }
        }
    }

    public static ArrayList<SearchNode> uniformCostExpand(SearchNode n) {
        ArrayList<SearchNode> successors = new ArrayList<>();
        for (ActionStatePair asp : uniformCostSuccessorFunction(n.state)) {
            SearchNode s = new SearchNode();
            s.state = asp.state;
            s.parentNode = n;
            s.action = asp.action;
            s.depth = n.depth + 1;
            s.cost = n.cost + stepCost(s);
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> uniformCostSuccessorFunction(State s) {
        int currentVertex = s.agentVertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = otherVertices;
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            State ns = new State(svsAgentVertex);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static double stepCost(SearchNode s) {
        double stepCost = lockProb(s.state);
        return stepCost;
    }

    public static SearchNode makeInitialNode(State s) {
        SearchNode n = new SearchNode();
        n.state = s;
        n.depth = 0;
        n.parentNode = null;
        n.cost = 0;
        n.action = s.agentVertex;
        return n;
    }

    public static boolean goalTest(int goal, State test) {
        return test.agentVertex == goal;
    }

    public static ArrayList<SearchNode> solutionPath(SearchNode n) {
        ArrayList<SearchNode> s = new ArrayList<>();
        do {
            s.add(n);
            n = n.parentNode;
        } while (n != null);
        return s;
    }
    private static double lockProb(State state) {
        EnumerationAsk ea = new EnumerationAsk();
        String qn = "l0v"+state.agentVertex;
        RandomVariable qv = new RandomVariable(null);
       for (RandomVariable rv : bn.variables) {
            if (rv.name.equals(qn)) {
                qv = rv;
           }
    }
       double[] result = ea.enumerationAsk(qv, evidences, bn);
       //System.out.println();
      // System.out.println("at vertex "+state.agentVertex+": "+result[0]);
        return result[0];
    }
    

    public static void readGraph() throws FileNotFoundException {
        Scanner inFile;
        File file = new File("graph3.txt");
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        numberOfTypes = inFile.nextInt();
        graph = new Graph(numberOfVertices);
        String s;
        if (inFile.next().equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        if (numberOfTypes == 1) {
            double v;
            double k;
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key1Prob = new double[]{v, k};
        }
        if (numberOfTypes == 2) {
            double v;
            double k;
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key1Prob = new double[]{v, k};
            v = inFile.nextDouble();
            k = inFile.nextDouble();
            //format {1,0}  {true,false}
            key2Prob = new double[]{v, k};
        }
        Scanner input;
        int initialVertex, goalVertex;
         //Read initial vertex
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex: ");
        initialVertex = input.nextInt();
        //Read goal vertex
        input = new Scanner(System.in);
        System.out.print(
                "Goal vertex: ");
        goalVertex = input.nextInt();
        initialState = new State(initialVertex);
        goalState = goalVertex;
        
    }
}
