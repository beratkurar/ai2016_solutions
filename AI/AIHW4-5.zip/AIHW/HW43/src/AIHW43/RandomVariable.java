/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW43;

/**
 *
 * @author B
 */
public class RandomVariable {

    String name;
    int value;

    public RandomVariable(String n) {
        name = n;
        value = 6; //initally non assigned false=0 or true=1, 6 means not assigned
    }
}
