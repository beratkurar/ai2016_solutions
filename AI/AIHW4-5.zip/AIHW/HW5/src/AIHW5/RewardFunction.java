package AIHW5;

/**
 * An interface for MDP reward functions.
 * 
 * @param <S>
 *            the state type.
 * @author Ciaran O'Reilly
 * @author Ravi Mohan
 */
public class RewardFunction {
	public RewardFunction(State state)
        {
            
        }
	/**
	 * Get the reward associated with being in state s.
	 * 
	 * @param s
	 *            the state whose award is sought.
	 * @return the reward associated with being in state s.
	 */
	double reward(State state)
        {
            return 0;
        }
}