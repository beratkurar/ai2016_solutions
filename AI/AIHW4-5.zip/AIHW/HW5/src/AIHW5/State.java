/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW5;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author B
 */
public class State {

    public int agentVertex;
    public Map<Integer,Integer> keyVertices;
    public Map<Integer,Integer> lockVertices;
    public int carry;

    public State() {

    }

    public State(int av, HashMap kv, HashMap lv, int c) {
        agentVertex = av;
        keyVertices = kv;
        lockVertices = lv;
        carry = c;
    }

}
