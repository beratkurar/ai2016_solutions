package AIHW5;

import java.util.Set;


/**
 * An interface for MDP action functions.
 * 
 * @param <S>
 *            the state type.
 * @param <A>
 *            the action type.
 * 
 * @author Ciaran O'Reilly
 * @author Ravi Mohan
 */
public class ActionsFunction {
    
    public ActionsFunction(State state)
    {
        
    }
    
    
	/**
	 * Get the set of actions for state s.
	 * 
	 * @param s
	 *            the state.
	 * @return the set of actions for state s.
	 */
    Set<Integer> actions(State state)
    {
        return null;
    }
	
}
