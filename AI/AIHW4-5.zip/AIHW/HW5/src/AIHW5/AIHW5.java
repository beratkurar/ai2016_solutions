package AIHW5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import static AIHW5.Test.combinations;

/**
 *
 * @author B
 */
public class AIHW5 {

    public static int numberOfVertices;
    public static int numberOfKeys;
    public static int numberOfLocks;
    public static int numberOfCarries;
    public static Graph graph;
    public static Map<Integer, Double> keyVertexToProbMap = new HashMap();
    public static Map<Integer, Double> lockVertexToProbMap = new HashMap();
    public static Set<Integer> probKeyVertices = new HashSet();
    public static Set<Integer> probLockVertices = new HashSet();
    public static int numberOfAllPossibleStates;
    public static List<State> allPossibleStates;
    public static int startVertex = 0;
    public static int goalVertex = 4;
    public static Set<State> terminals;
    public static int numberOfIterations = 0;
    public static Map<State, Integer> policy;

    public static void main(String[] args) throws FileNotFoundException {
        readGraph();
        probKeyVertices.addAll(keyVertexToProbMap.keySet());
        probLockVertices.addAll(lockVertexToProbMap.keySet());
        numberOfCarries = numberOfKeys + 1;
        //write graph
        System.out.println(numberOfVertices + "  # of vertices");
        System.out.println(numberOfKeys + "  # of possible keys");
        System.out.println(numberOfLocks + "  # of possible locks");
        System.out.println("Edges");
        for (Vertex v : graph.vertexList) {
            for (Edge e : v.edgeList) {
                System.out.println(e.source + " " + e.destination + " " + e.weight);
            }
        }
        System.out.println("Possible Keys");
        System.out.println(keyVertexToProbMap);
        System.out.println("Possible Locks");
        System.out.println(lockVertexToProbMap);
        //Enumerate all possible states into a list
        numberOfAllPossibleStates = numberOfVertices * (numberOfKeys * 3) * (numberOfLocks * 3) * (numberOfCarries);
        allPossibleStates = new ArrayList();
        for (int a = 0; a < numberOfVertices; a++) {
            for (int c = 0; c < numberOfCarries; c++) {
                Map<Integer, Set<Integer>> kmap = new HashMap<Integer, Set<Integer>>() {
                    {
                        for (int k : probKeyVertices) {
                            put(k, new HashSet<Integer>() {
                                {
                                    add(0);
                                    add(1);
                                    add(2);
                                }
                            });
                        }
                    }
                };
                List<Map<Integer, Integer>> klist = new LinkedList<>();
                combinations(kmap, klist);
                for (Map<Integer, Integer> kcombination : klist) {
                    Map<Integer, Set<Integer>> lmap = new HashMap<Integer, Set<Integer>>() {
                        {
                            for (int k : probLockVertices) {
                                put(k, new HashSet<Integer>() {
                                    {
                                        add(0);
                                        add(1);
                                        add(2);
                                    }
                                });
                            }
                        }
                    };
                    List<Map<Integer, Integer>> llist = new LinkedList<>();
                    combinations(lmap, llist);
                    for (Map<Integer, Integer> lcombination : llist) {
                        State state = new State();
                        state.agentVertex = a;
                        state.carry = c;
                        state.keyVertices = kcombination;
                        state.lockVertices = lcombination;
                        allPossibleStates.add(state);
                    }
                }
            }
        }
        //create terminal states set
        terminals = new HashSet<>();
        for (int i = 0; i < allPossibleStates.size(); i++) {
            if (allPossibleStates.get(i).agentVertex == goalVertex) {
                terminals.add(allPossibleStates.get(i));
            }
        }
        System.out.println("\n\n" + "All possible states");
        for (int i = 0; i < allPossibleStates.size(); i++) {
            System.out.println(i + ")" + allPossibleStates.get(i).agentVertex + ","
                    + allPossibleStates.get(i).keyVertices + ","
                    + allPossibleStates.get(i).lockVertices + ","
                    + allPossibleStates.get(i).carry);
        }
        System.out.println("\n\n" + "Terminal states");
        int u = 0;
        for (State s : terminals) {
            System.out.println(u + ")" + s.agentVertex + ","
                    + s.keyVertices + "," + s.lockVertices + ","
                    + s.carry);
            u++;
        }
        Map<State, Double> convergence = valueIteration(0.01);
        System.out.println("\n\nThe Policy");
        int p = 0;
        for (Entry e : policy.entrySet()) {
            State s = (State) e.getKey();
            int a = (Integer) e.getValue();
            System.out.println(p + ") " + s.agentVertex + ", " + s.keyVertices + ", "
                    + s.lockVertices + ", " + s.carry + ", act: " + a);
            p++;
        }
        System.out.println("\n\nUtilities after " + numberOfIterations + " iterations");
        int y = 0;
        for (Entry<State, Double> e : convergence.entrySet()) {
            State s = e.getKey();
            double d = e.getValue();
            System.out.println(y + ")" + s.agentVertex + " "
                    + s.keyVertices + " " + s.lockVertices + " " + s.carry
                    + "  utl= " + d);
            y++;
        }
    }

    public static Map<State, Double> valueIteration(double epsilon) {
        Set<State> states = new HashSet();
        for (State s : allPossibleStates) {
            states.add(s);
        }
        Map<State, Double> U = Util.create(states, new Double(0));
        Map<State, Double> Udelta = Util.create(states, new Double(0));
        double delta = 0;
        do {
            delta = 0;
            policy = new HashMap<>();
            U.putAll(Udelta);
            for (State s : states) {
                if (numberOfIterations == 0) {
                    System.out.println("\nState:  " + s.agentVertex + " "
                            + s.keyVertices + " " + s.lockVertices + " " + s.carry);
                }
                int besta = -1;
                Set<Integer> actions = actions(s);
                double aMax = 0;
                //if terminal --> no action. actions(terminal)=empty set
                //if terminal state --> utility= 0
                //if not terminal state --> utility= -infinity
                if (actions.size() > 0) {
                    aMax = Integer.MIN_VALUE;
                    for (int a : actions) {
                        double aSum = 0;
                        Map<State, Double> po = possibleOutcomes(s, a);
                        for (Entry e : po.entrySet()) {
                            State sn = (State) e.getKey();
                            Double p = (Double) e.getValue();
                            double u = 0.0;
                            for (State sta : U.keySet()) {
                                if (sta.agentVertex == sn.agentVertex
                                        && sta.keyVertices.equals(sn.keyVertices)
                                        && sta.lockVertices.equals(sn.lockVertices)
                                        && sta.carry == sn.carry) {
                                    u = U.get(sta);
                                }
                            }
                            if (numberOfIterations == 0) {
                                System.out.println("\t" + sn.agentVertex + " "
                                        + sn.keyVertices + " " + sn.lockVertices + " " + sn.carry
                                        + ": p=" + p + ", u=" + u);
                            }
                            aSum += p * u;
                        }
                        aSum = aSum + reward(s, a);
                        if (aSum > aMax) {
                            besta = a;
                            aMax = aSum;
                        }
                    }
                }
                policy.put((State) s, besta);
                Udelta.put((State) s, aMax);
                double d = Math.abs(Udelta.get(s) - U.get(s));
                if (d > delta) {
                    delta = d;
                }
            }
            numberOfIterations++;
        } while (delta > epsilon);
        return U;
    }

    private static Map<State, Double> possibleOutcomes(State s, int a) {
        List<State> outcomes = new ArrayList();
        Map<State, Double> stateAndProbToIt = new HashMap<>();
        if (s.lockVertices.containsKey(a) && s.lockVertices.get(a) == 1) {
            State ps = new State();
            ps.agentVertex = a;
            ps.carry = s.carry - 1;
            ps.keyVertices = new HashMap(s.keyVertices);
            ps.lockVertices = new HashMap(s.lockVertices);
            ps.lockVertices.put(a, 0);
            boolean bool = false;
            for (int n : neighbors(ps.agentVertex)) {
                if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)
                        || (ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                    bool = true;
                    break;
                }
            }
            if (bool) {
                //take all key and lock vertices with value=2
                Set<Integer> stocKeyVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)) {
                        stocKeyVertices.add(n);
                    }
                }
                Set<Integer> stocLockVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                        stocLockVertices.add(n);
                    }
                }
                //create all possible combinations
                Map<Integer, Set<Integer>> kmap = new HashMap<Integer, Set<Integer>>() {
                    {
                        for (int k : stocKeyVertices) {
                            put(k, new HashSet<Integer>() {
                                {
                                    add(0);
                                    add(1);
                                }
                            });
                        }
                    }
                };
                List<Map<Integer, Integer>> klist = new LinkedList<>();
                combinations(kmap, klist);
                for (Map<Integer, Integer> kcombination : klist) {
                    Map<Integer, Set<Integer>> lmap = new HashMap<Integer, Set<Integer>>() {
                        {
                            for (int k : stocLockVertices) {
                                put(k, new HashSet<Integer>() {
                                    {
                                        add(0);
                                        add(1);
                                    }
                                });
                            }
                        }
                    };
                    List<Map<Integer, Integer>> llist = new LinkedList<>();
                    combinations(lmap, llist);
                    for (Map<Integer, Integer> lcombination : llist) {
                        State sps = new State();
                        sps.agentVertex = ps.agentVertex;
                        sps.carry = ps.carry;
                        sps.keyVertices = new HashMap(ps.keyVertices);
                        for (Entry e : kcombination.entrySet()) {
                            sps.keyVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        sps.lockVertices = new HashMap(ps.lockVertices);
                        for (Entry e : lcombination.entrySet()) {
                            sps.lockVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        outcomes.add(sps);
                    }
                }
                for (State st : outcomes) {
                    double prob = 1.0;
                    for (Entry e : st.keyVertices.entrySet()) {
                        if (stocKeyVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * keyVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - keyVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    for (Entry e : st.lockVertices.entrySet()) {
                        if (stocLockVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * lockVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - lockVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    stateAndProbToIt.put((State) st, prob);
                }
            } else {
                outcomes.add(ps);
                stateAndProbToIt.put((State) ps, 1.0);
            }
        } else if (s.keyVertices.containsKey(a) && s.keyVertices.get(a) == 1) {
            State ps = new State();
            ps.agentVertex = a;
            ps.carry = s.carry + 1;
            ps.keyVertices = new HashMap(s.keyVertices);
            ps.keyVertices.put(a, 0);
            ps.lockVertices = new HashMap(s.lockVertices);
            boolean bool = false;
            for (int n : neighbors(ps.agentVertex)) {
                if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)
                        || (ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                    bool = true;
                    break;
                }
            }
            if (bool) {
                //take all key and lock vertices with value=2
                Set<Integer> stocKeyVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)) {
                        stocKeyVertices.add(n);
                    }
                }
                Set<Integer> stocLockVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                        stocLockVertices.add(n);
                    }
                }
                //create all possible combinations
                Map<Integer, Set<Integer>> kmap = new HashMap<Integer, Set<Integer>>() {
                    {
                        for (int k : stocKeyVertices) {
                            put(k, new HashSet<Integer>() {
                                {
                                    add(0);
                                    add(1);
                                }
                            });
                        }
                    }
                };
                List<Map<Integer, Integer>> klist = new LinkedList<>();
                combinations(kmap, klist);
                for (Map<Integer, Integer> kcombination : klist) {
                    Map<Integer, Set<Integer>> lmap = new HashMap<Integer, Set<Integer>>() {
                        {
                            for (int k : stocLockVertices) {
                                put(k, new HashSet<Integer>() {
                                    {
                                        add(0);
                                        add(1);
                                    }
                                });
                            }
                        }
                    };
                    List<Map<Integer, Integer>> llist = new LinkedList<>();
                    combinations(lmap, llist);
                    for (Map<Integer, Integer> lcombination : llist) {
                        State sps = new State();
                        sps.agentVertex = ps.agentVertex;
                        sps.carry = ps.carry;
                        sps.keyVertices = new HashMap(ps.keyVertices);
                        for (Entry e : kcombination.entrySet()) {
                            sps.keyVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        sps.lockVertices = new HashMap(ps.lockVertices);
                        for (Entry e : lcombination.entrySet()) {
                            sps.lockVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        outcomes.add(sps);
                    }
                }
                for (State st : outcomes) {
                    double prob = 1.0;
                    for (Entry e : st.keyVertices.entrySet()) {
                        if (stocKeyVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * keyVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - keyVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    for (Entry e : st.lockVertices.entrySet()) {
                        if (stocLockVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * lockVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - lockVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    stateAndProbToIt.put((State) st, prob);
                }
            } else {
                outcomes.add(ps);
                stateAndProbToIt.put((State) ps, 1.0);
            }
        } else {
            State ps = new State();
            ps.agentVertex = a;
            ps.carry = s.carry;
            ps.keyVertices = new HashMap(s.keyVertices);
            ps.lockVertices = new HashMap(s.lockVertices);
            boolean bool = false;
            for (int n : neighbors(ps.agentVertex)) {
                if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)
                        || (ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                    bool = true;
                    break;
                }
            }
            if (bool) {
                //take all key and lock vertices with value=2
                Set<Integer> stocKeyVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.keyVertices.containsKey(n) && ps.keyVertices.get(n) == 2)) {
                        stocKeyVertices.add(n);
                    }
                }
                Set<Integer> stocLockVertices = new HashSet();
                for (int n : neighbors(ps.agentVertex)) {
                    if ((ps.lockVertices.containsKey(n) && ps.lockVertices.get(n) == 2)) {
                        stocLockVertices.add(n);
                    }
                }
                //create all possible combinations
                Map<Integer, Set<Integer>> kmap = new HashMap<Integer, Set<Integer>>() {
                    {
                        for (int k : stocKeyVertices) {
                            put(k, new HashSet<Integer>() {
                                {
                                    add(0);
                                    add(1);
                                }
                            });
                        }
                    }
                };
                List<Map<Integer, Integer>> klist = new LinkedList<>();
                combinations(kmap, klist);
                for (Map<Integer, Integer> kcombination : klist) {
                    Map<Integer, Set<Integer>> lmap = new HashMap<Integer, Set<Integer>>() {
                        {
                            for (int k : stocLockVertices) {
                                put(k, new HashSet<Integer>() {
                                    {
                                        add(0);
                                        add(1);
                                    }
                                });
                            }
                        }
                    };
                    List<Map<Integer, Integer>> llist = new LinkedList<>();
                    combinations(lmap, llist);
                    for (Map<Integer, Integer> lcombination : llist) {
                        State sps = new State();
                        sps.agentVertex = ps.agentVertex;
                        sps.carry = ps.carry;
                        sps.keyVertices = new HashMap(ps.keyVertices);
                        for (Entry e : kcombination.entrySet()) {
                            sps.keyVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        sps.lockVertices = new HashMap(ps.lockVertices);
                        for (Entry e : lcombination.entrySet()) {
                            sps.lockVertices.put((Integer) e.getKey(), (Integer) e.getValue());
                        }
                        outcomes.add(sps);
                    }
                }
                for (State st : outcomes) {
                    double prob = 1.0;
                    for (Entry e : st.keyVertices.entrySet()) {
                        if (stocKeyVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * keyVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - keyVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    for (Entry e : st.lockVertices.entrySet()) {
                        if (stocLockVertices.contains((int) e.getKey())) {
                            if ((int) e.getValue() == 1) {
                                prob = prob * lockVertexToProbMap.get((int) e.getKey());
                            }
                            if ((int) e.getValue() == 0) {
                                prob = prob * (1 - lockVertexToProbMap.get((int) e.getKey()));
                            }
                        }
                    }
                    stateAndProbToIt.put((State) st, prob);
                }
            } else {
                outcomes.add(ps);
                stateAndProbToIt.put((State) ps, 1.0);
            }
        }
        return stateAndProbToIt;
    }

    public static List<Integer> neighbors(int v) {
        int currentVertex = v;
        int otherVertex;
        List<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        return otherVertices;
    }

    public static Set<Integer> actions(State state) {
        //no actions allowed from terminal states
        if (terminals.contains(state)) {
            return Collections.EMPTY_SET;
        }
        //select all neigbors
        int currentVertex = state.agentVertex;
        int otherVertex;
        Set<Integer> otherVertices = new HashSet();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        //select from neigbors non locked ones or if locked and you have akey
        Set<Integer> selectedVertices = new HashSet();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : getKeysFromValue(state.lockVertices, 1)) {
                if (ov == i) {
                    bool = false;
                    break;
                }
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                if (state.carry > 0) {
                    selectedVertices.add(ov);
                }
            }
        }
        return selectedVertices;
    }

    public static List<Integer> getKeysFromValue(Map<Integer, Integer> hm, Integer value) {
        List<Integer> list = new ArrayList();
        for (int o : hm.keySet()) {
            if (hm.get(o).equals(value)) {
                list.add(o);
            }
        }
        return list;
    }

    public static double reward(State state, int action) {
        int rew = Integer.MIN_VALUE;
        for (Edge e : graph.vertexList[state.agentVertex].edgeList) {
            int currentVertex = state.agentVertex;
            int otherVertex;
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            if (otherVertex == action) {
                rew = -e.weight;
            }
        }
        return rew;
    }

    public static void readGraph() throws FileNotFoundException {
        Scanner inFile;
        File file = new File("graph2.txt");
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        numberOfKeys = inFile.nextInt();
        numberOfLocks = inFile.nextInt();
        graph = new Graph(numberOfVertices);
        String s;
        if (inFile.next().equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        int kv;
        double kp;
        while (inFile.hasNext()) {
            s = inFile.next();
            if (s.equals("L")) {
                break;
            }
            kv = Integer.parseInt(s);
            kp = inFile.nextDouble();
            keyVertexToProbMap.put(kv, kp);
        }
        int lv;
        double lp;
        while (inFile.hasNext()) {
            lv = inFile.nextInt();
            lp = inFile.nextDouble();
            lockVertexToProbMap.put(lv, lp);
        }
    }
}
