package AIHW5;

import java.util.Set;


/**
 * Default implementation of the MarkovDecisionProcess<S, A> interface.
 * 
 * @param <S>
 *            the state type.
 * @param <A>
 *            the action type.
 * 
 * @author Ciaran O'Reilly
 * @author Ravi Mohan
 */
public class MDP {
	private Set<State> states = null;
	private State initialState = null;
	private ActionsFunction actionsFunction = null;
	private TransitionProbabilityFunction transitionProbabilityFunction = null;
	private RewardFunction rewardFunction = null;

	public MDP(Set<State> states, State initialState,
			ActionsFunction actionsFunction,
			TransitionProbabilityFunction transitionProbabilityFunction,
			RewardFunction rewardFunction) {
		this.states = states;
		this.initialState = initialState;
		this.actionsFunction = actionsFunction;
		this.transitionProbabilityFunction = transitionProbabilityFunction;
		this.rewardFunction = rewardFunction;
	}

	
	public Set<State> states() {
		return states;
	}

	
	public State getInitialState() {
		return initialState;
	}

	
	public Set<Integer> actions(State s) {
		return actionsFunction.actions(s);
	}

	
	public double transitionProbability(State sDelta, State s, int a) {
		return transitionProbabilityFunction.probability(sDelta, s, a);
	}

	
	public double reward(State s) {
		return rewardFunction.reward(s);
	}

}
