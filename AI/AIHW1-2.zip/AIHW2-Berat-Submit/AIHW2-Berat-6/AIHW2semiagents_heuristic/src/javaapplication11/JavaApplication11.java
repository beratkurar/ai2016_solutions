/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 *
 * @author B
 */
public class JavaApplication11 {

    public static int goalVertex1, goalVertex2;
    public static State initialState;
    public static Graph graph;

    public static void main(String[] args) throws FileNotFoundException {
        readGraph();
        int count = 1;
        while (count < 100) {
            initialState = alphaBetaSearch1(makeInitialNode1(initialState));
            
            System.out.println("agent1 goes to: " + initialState.agent1Vertex);
            System.out.println();
            if (initialState.agent1Vertex == goalVertex1) {
                break;
            }
            initialState = alphaBetaSearch2(makeInitialNode2(initialState));
           
            System.out.println("agent2 goes to: " + initialState.agent2Vertex);
            System.out.println();
            if (initialState.agent2Vertex == goalVertex2) {
                break;
            }
            count++;
        }
    }

    public static State alphaBetaSearch1(Node node) {
        
        int[] bestValue = new int[2];
        bestValue[0] = -1000;
        bestValue[1] = -1000;
        Node nextNode = node;
        for (Node n : maxExpandNode1(node)) {
            System.out.print("minnode:" );
            stateToString(n.state);
            int[] value = minValue1(n);
            System.out.println("minvalue: " + value[0] + "," + value[1]);
            if (value[0] > bestValue[0]) {
                bestValue[0] = value[0];
                bestValue[1] = value[1];
                nextNode = n;
            } else if (value[0] == bestValue[0] && value[1] > bestValue[1]) {
                bestValue[0] = value[0];
                bestValue[1] = value[1];
                nextNode = n;
            }
        }
        return nextNode.state;
    }

    public static int[] maxValue1(Node node) {
        if (cutoff1(node)) {
            System.out.print("cutoff at max level: ");
            stateToString(node.state);
            int[] eval= eval2(node);
            System.out.println("eval: "+eval[0]+","+eval[1]);
            return eval;
        }
        if (terminal1(node)) {
            System.out.print("terminal at max level: ");
            stateToString(node.state);
            return utility1(node);
        }
       
        
            int[] mv;
            int[] rv = new int[2];
            rv[0] = -1000;
            rv[1] = -1000;
            for (Node n : maxExpandNode1(node)) {
                mv = minValue1(n);
                if (mv[0] > rv[0]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                } else if (mv[0] == rv[0] && mv[1] > rv[1]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                }
            }
            return rv;
        
    }

    public static int[] minValue1(Node node) {
        if (cutoff1(node)) {
            System.out.print("cutoff at min level: ");
            stateToString(node.state);
            int[] eval= eval1(node);
            System.out.println("eval: "+eval[0]+","+eval[1]);
            return eval;
        }
        if (terminal1(node)) {
            System.out.print("terminal at min level: ");
            stateToString(node.state);
            return utility1(node);
        }
       
      
            int[] mv;
            int[] rv = new int[2];
            rv[0] = -1000;
            rv[1] = -1000;
            for (Node n : minExpandNode1(node)) {
                mv = maxValue1(n);
                if (mv[1] > rv[1]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                } else if (mv[1] == rv[1] && mv[0] > rv[0]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                }
            }
            return rv;
        
    }

    public static ArrayList<Node> maxExpandNode1(Node node) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : maxSuccessorFunction1(node.state)) {
            Node n = new Node();
            n.state = asp.state;
            n.parentNode = node;
            n.agent1Action = asp.state.agent1Vertex;
            n.agent2Action = asp.state.agent2Vertex;
            n.depth1 = node.depth1 + 1;
            n.depth2 = node.depth2;
            successors.add(n);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> maxSuccessorFunction1(State state) {
        int currentVertex = state.agent1Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : state.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                for (int i = 0; i < state.lockVertices.length; i++) {
                    if ((ov == state.lockVertices[i]) && (state.agent1Vertex == state.keyVertices[i])) {
                        selectedVertices.add(ov);
                    }
                }
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[state.keyVertices.length];
            for (int i = 0; i < state.keyVertices.length; i++) {
                if (state.keyVertices[i] == state.agent1Vertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = state.keyVertices[i];
                }
            }
            int[] svsLockVertices = new int[state.lockVertices.length];
            for (int i = 0; i < state.lockVertices.length; i++) {
                if (sv == state.lockVertices[i]) {
                    svsLockVertices[i] = -6;
                } else {
                    svsLockVertices[i] = state.lockVertices[i];
                }
            }
            State ns = new State(svsAgentVertex, state.agent2Vertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static ArrayList<Node> minExpandNode1(Node node) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : minSuccessorFunction1(node.state)) {
            Node n = new Node();
            n.state = asp.state;
            n.parentNode = node;
            n.agent1Action = asp.state.agent1Vertex;
            n.agent2Action = asp.state.agent2Vertex;
            n.depth1 = node.depth1;
            n.depth2 = node.depth2 + 1;
            successors.add(n);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> minSuccessorFunction1(State state) {
        int currentVertex = state.agent2Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : state.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                for (int i = 0; i < state.lockVertices.length; i++) {
                    if ((ov == state.lockVertices[i]) && (state.agent2Vertex == state.keyVertices[i])) {
                        selectedVertices.add(ov);
                    }
                }
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[state.keyVertices.length];
            for (int i = 0; i < state.keyVertices.length; i++) {
                if (state.keyVertices[i] == state.agent2Vertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = state.keyVertices[i];
                }
            }
            int[] svsLockVertices = new int[state.lockVertices.length];
            for (int i = 0; i < state.lockVertices.length; i++) {
                if (sv == state.lockVertices[i]) {
                    svsLockVertices[i] = -6;
                } else {
                    svsLockVertices[i] = state.lockVertices[i];
                }
            }
            State ns = new State(state.agent1Vertex, svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static Node makeInitialNode1(State state) {
        Node n = new Node();
        n.state = state;
        n.depth1 = 0;
        n.parentNode = null;
        n.depth2 = 0;
        n.agent1Action = state.agent1Vertex;
        n.agent2Action = state.agent2Vertex;
        return n;
    }

    public static boolean cutoff1(Node node) {
        return node.depth1 >=2;
    }

    public static int[] eval1(Node node) {
        int[] eval=new int[2];
        eval[0]=-node.depth1-uniformCostSearch1(node.state,goalVertex1);
        eval[1]=-node.depth2-uniformCostSearch2(node.state,goalVertex2);
        return eval;
    }

    public static boolean terminal1(Node node) {
        return node.state.agent1Vertex == goalVertex1 || node.state.agent2Vertex == goalVertex2;
    }

    public static int[] utility1(Node node) {
        int[] u = new int[2];
        if (node.state.agent1Vertex == goalVertex1) {
            u[0] = -node.depth1;
            u[1] = -1000;
        } else {
            u[0] = -1000;
            u[1] = -node.depth2;
        }
        return u;
    }

    public static State alphaBetaSearch2(Node node) {
        
        int[] bestValue = new int[2];
        bestValue[0] = -1000;
        bestValue[1] = -1000;
        Node nextNode = node;
        for (Node n : maxExpandNode2(node)) {
            System.out.print("minnode:");
            stateToString(n.state);
            int[] value = minValue2(n);
            System.out.println("minvalue: " + value[0] + "," + value[1]);
            if (value[1] > bestValue[1]) {
                bestValue[0] = value[0];
                bestValue[1] = value[1];
                nextNode = n;
            } else if (value[1] == bestValue[1] && value[0] > bestValue[0]) {
                bestValue[0] = value[0];
                bestValue[1] = value[1];
                nextNode = n;
            }
        }
        return nextNode.state;
    }

    public static int[] maxValue2(Node node) {
        if (cutoff2(node)) {
            System.out.print("cutoff at max level: ");
            stateToString(node.state);
            int[] eval= eval2(node);
            System.out.println("eval: "+eval[0]+","+eval[1]);
            return eval;
        }
        if (terminal2(node)) {
            System.out.print("terminal at max level: ");
            stateToString(node.state);
                    
            return utility2(node);
        }
        
            int[] mv;
            int[] rv = new int[2];
            rv[0] = -1000;
            rv[1] = -1000;
            for (Node n : maxExpandNode2(node)) {
                mv = minValue2(n);
                if (mv[1] > rv[1]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                } else if (mv[1] == rv[1] && mv[0] > rv[0]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                }
            }
            return rv;
       
    }

    public static int[] minValue2(Node node) {
        if (cutoff2(node)) {
            System.out.print("cutoff at min level: ");
            stateToString(node.state);
            int[] eval= eval2(node);
            System.out.println("eval: "+eval[0]+","+eval[1]);
            return eval;
        }
        if (terminal2(node)) {
            System.out.print("terminal at min level: ");
            stateToString(node.state);
            return utility2(node);
        }
        
        
            int[] mv;
            int[] rv = new int[2];
            rv[0] = -1000;
            rv[1] = -1000;
            for (Node n : minExpandNode2(node)) {
                mv = maxValue2(n);
                if (mv[0] > rv[0]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                } else if (mv[0] == rv[0] && mv[1] > rv[1]) {
                    rv[1] = mv[1];
                    rv[0] = mv[0];
                }
            }
            return rv;
        
    }

    public static ArrayList<Node> maxExpandNode2(Node node) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : maxSuccessorFunction2(node.state)) {
            Node n = new Node();
            n.state = asp.state;
            n.parentNode = node;
            n.agent1Action = asp.state.agent1Vertex;
            n.agent2Action = asp.state.agent2Vertex;
            n.depth1 = node.depth1;
            n.depth2 = node.depth2 + 1;
            successors.add(n);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> maxSuccessorFunction2(State state) {
        int currentVertex = state.agent2Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : state.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                for (int i = 0; i < state.lockVertices.length; i++) {
                    if ((ov == state.lockVertices[i]) && (state.agent2Vertex == state.keyVertices[i])) {
                        selectedVertices.add(ov);
                    }
                }
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[state.keyVertices.length];
            for (int i = 0; i < state.keyVertices.length; i++) {
                if (state.keyVertices[i] == state.agent2Vertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = state.keyVertices[i];
                }
            }
            int[] svsLockVertices = new int[state.lockVertices.length];
            for (int i = 0; i < state.lockVertices.length; i++) {
                if (sv == state.lockVertices[i]) {
                    svsLockVertices[i] = -6;
                } else {
                    svsLockVertices[i] = state.lockVertices[i];
                }
            }
            State ns = new State(state.agent1Vertex, svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static ArrayList<Node> minExpandNode2(Node node) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : minSuccessorFunction2(node.state)) {
            Node n = new Node();
            n.state = asp.state;
            n.parentNode = node;
            n.agent1Action = asp.state.agent1Vertex;
            n.agent2Action = asp.state.agent2Vertex;
            n.depth1 = node.depth1 + 1;
            n.depth2 = node.depth2;
            successors.add(n);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> minSuccessorFunction2(State state) {
        int currentVertex = state.agent1Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : state.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                for (int i = 0; i < state.lockVertices.length; i++) {
                    if ((ov == state.lockVertices[i]) && (state.agent1Vertex == state.keyVertices[i])) {
                        selectedVertices.add(ov);
                    }
                }
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[state.keyVertices.length];
            for (int i = 0; i < state.keyVertices.length; i++) {
                if (state.keyVertices[i] == state.agent1Vertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = state.keyVertices[i];
                }
            }
            int[] svsLockVertices = new int[state.lockVertices.length];
            for (int i = 0; i < state.lockVertices.length; i++) {
                if (sv == state.lockVertices[i]) {
                    svsLockVertices[i] = -6;
                } else {
                    svsLockVertices[i] = state.lockVertices[i];
                }
            }
            State ns = new State(svsAgentVertex, state.agent2Vertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static Node makeInitialNode2(State state) {
        Node n = new Node();
        n.state = state;
        n.depth1 = 0;
        n.parentNode = null;
        n.depth2 = 0;
        n.agent1Action = state.agent1Vertex;
        n.agent2Action = state.agent2Vertex;
        return n;
    }

    public static boolean cutoff2(Node node) {
        return node.depth2 >=2;
    }

    public static int[] eval2(Node node) {
        int[] eval=new int[2];
        eval[0]=-node.depth1-uniformCostSearch1(node.state,goalVertex1);
        eval[1]=-node.depth2-uniformCostSearch2(node.state,goalVertex2);
        return eval;
    }

    public static boolean terminal2(Node node) {
        return node.state.agent1Vertex == goalVertex1 || node.state.agent2Vertex == goalVertex2;
    }

    public static int[] utility2(Node node) {
        int[] u = new int[2];
        if (node.state.agent1Vertex == goalVertex1) {
            u[0] = -node.depth1;
            u[1] = -1000;
        } else {
            u[0] = -1000;
            u[1] = -node.depth2;
        }
        return u;
    }

    public static void readGraph() throws FileNotFoundException {
        Scanner input;
        Scanner inFile;
        int numberOfVertices;
        int numberOfKeysAndLocks;
        int initialVertex1, initialVertex2;
        //read file name
        //input = new Scanner(System.in);
        //System.out.print(
        //         "Graph file name: ");
        File file = new File("graph4.txt");
        //Read number of nodes
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        //Read number of keys and locks
        numberOfKeysAndLocks = inFile.nextInt();
        //read edges, weights, keys, locks
        graph = new Graph(numberOfVertices);
        int[] keys = new int[numberOfKeysAndLocks];
        int[] locks = new int[numberOfKeysAndLocks];
        String s;
        if (inFile.next()
                .equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                if (s.equals("L")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        int v;
        int k;
        while (inFile.hasNext()) {
            s = inFile.next();
            if (s.equals("L")) {
                break;
            }
            v = Integer.parseInt(s);
            k = inFile.nextInt();
            keys[k] = v;
        }
        int l;
        while (inFile.hasNext()) {
            v = inFile.nextInt();
            l = inFile.nextInt();
            locks[l] = v;
        }
        //Read initial vertex
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex1: ");
        initialVertex1 = input.nextInt();
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex2: ");
        initialVertex2 = input.nextInt();
        //Read goal vertex
        input = new Scanner(System.in);
        System.out.print(
                "Goal vertex1: ");
        goalVertex1 = input.nextInt();
        input = new Scanner(System.in);
        System.out.print(
                "Goal vertex2: ");
        goalVertex2 = input.nextInt();
        initialState = new State(initialVertex1, initialVertex2, keys, locks);
    }
    
    public static void stateToString(State s)
    {
        System.out.print(s.agent1Vertex+","+s.agent2Vertex+",");
        for(int i:s.keyVertices)
        {
            System.out.print(i+",");
        }
        for(int i:s.lockVertices)
        {
            System.out.print(i+",");
        }
        System.out.println();
    }
    
    
    
    
    
    
     public static int uniformCostSearch1(State initialState, int goalState) {
        ArrayList<Integer> closed = new ArrayList<>();
        PriorityQueue<Node> fringe = new PriorityQueue<>(1, new Comparator<Node>() {
            @Override
            public int compare(Node n0, Node n1) {
                return new Integer((n0.depth1)).compareTo(n1.depth1);
            }
        });
        fringe.add(makeInitialNode11(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                //no solution
                return 100;
            }
            Node n = fringe.remove();
            if (goalTest1(goalState, n.state)) {
                //there is a solution
                return n.depth1;
            }
            if (!closed.contains(n.state.agent1Vertex)) {
                closed.add(n.state.agent1Vertex);
                fringe.addAll(uniformCostExpand1(n));
            }
        }
    }

    public static ArrayList<Node> uniformCostExpand1(Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : uniformCostSuccessorFunction1(n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.depth1 = n.depth1 + 1;
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> uniformCostSuccessorFunction1(State s) {
        int currentVertex = s.agent1Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = otherVertices;
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = s.keyVertices;
            int[] svsLockVertices = s.lockVertices;
            State ns = new State(svsAgentVertex, s.agent2Vertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static Node makeInitialNode11(State s) {
        Node n = new Node();
        n.state = s;
        n.depth1 = 0;
        n.parentNode = null;
        n.depth2 = 0;
        return n;
    }

    public static boolean goalTest1(int goal, State test) {
        return test.agent1Vertex == goal;
    }

    public static int uniformCostSearch2(State initialState, int goalState) {
        ArrayList<Integer> closed = new ArrayList<>();
        PriorityQueue<Node> fringe = new PriorityQueue<>(1, new Comparator<Node>() {
            @Override
            public int compare(Node n0, Node n1) {
                return new Integer((n0.depth2)).compareTo(n1.depth2);
            }
        });
        fringe.add(makeInitialNode22(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                //no solution
                return 100;
            }
            Node n = fringe.remove();
            if (goalTest2(goalState, n.state)) {
                //there is a solution
                return n.depth2;
            }
            if (!closed.contains(n.state.agent2Vertex)) {
                closed.add(n.state.agent2Vertex);
                fringe.addAll(uniformCostExpand2(n));
            }
        }
    }

    public static ArrayList<Node> uniformCostExpand2(Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : uniformCostSuccessorFunction2(n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.depth2 = n.depth2 + 1;
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> uniformCostSuccessorFunction2(State s) {
        int currentVertex = s.agent2Vertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = otherVertices;
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = s.keyVertices;
            int[] svsLockVertices = s.lockVertices;
            State ns = new State(s.agent1Vertex, svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static Node makeInitialNode22(State s) {
        Node n = new Node();
        n.state = s;
        n.depth1 = 0;
        n.parentNode = null;
        n.depth2 = 0;
        return n;
    }

    public static boolean goalTest2(int goal, State test) {
        return test.agent2Vertex == goal;
    }
    
    
    
    
}
