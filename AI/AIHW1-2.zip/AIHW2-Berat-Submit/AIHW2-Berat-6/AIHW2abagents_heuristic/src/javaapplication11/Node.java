/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

/**
 *
 * @author B
 */
public class Node {

    Node parentNode;
    int depth1 ;
    int depth2 ;
    int agent1Action;
    int agent2Action;
    int value;
    State state;
}
