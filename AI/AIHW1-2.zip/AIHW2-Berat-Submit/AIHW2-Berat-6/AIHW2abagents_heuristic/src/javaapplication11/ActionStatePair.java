/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

/**
 *
 * @author B
 */
public class ActionStatePair {

    int action;
    State state;

    ActionStatePair(int a, State s) {
        action=a;
        state=s;
    }
}
