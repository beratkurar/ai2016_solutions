/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

/**
 *
 * @author B
 */
public class State {

    int agent1Vertex;
    int agent2Vertex;
    int[] keyVertices;
    int[] lockVertices;
    
    State(int av1,int av2,int[] kv, int[] lv)
    {
        agent1Vertex=av1;
        agent2Vertex=av2;
        keyVertices=kv;
        lockVertices=lv;
        
    }

}


