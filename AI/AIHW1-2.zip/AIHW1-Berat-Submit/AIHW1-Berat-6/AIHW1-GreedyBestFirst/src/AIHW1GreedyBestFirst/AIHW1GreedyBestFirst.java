/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1GreedyBestFirst;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 *
 * @author B
 */
public class AIHW1GreedyBestFirst {

    public static Graph graph;
    public static State initialState;
    public static int goalState;
    public static int totalCost = 0, totalDepth = 0;

    public static void main(String[] args) throws FileNotFoundException {
        //read graph
        readGraph();
        greedyBestFirstAgent();
        System.out.println("Greedy best first agent>> Total cost= " + totalCost);
        System.out.println("Greedy best first agent>> Total depth= " + totalDepth);
        int p1 = 1 * totalCost + totalDepth;
        int p2 = 100 * totalCost + totalDepth;
        int p3 = 1000 * totalCost + totalDepth;
        System.out.println("Greedy best first agent>> performance1: " + p1);
        System.out.println("Greedy best first agent>> performance2: " + p2);
        System.out.println("Greedy best first agent>> performance3: " + p3);
    }

    public static void greedyBestFirstAgent() {
        //search solution
        Solution sol = greedyBestFirstSearch();
        if (!sol.failure) {
            //display solution path
            System.out.print("Greedy best first agent>> Solution path: ");
            for (Node n : sol.path) {
                System.out.print(n.action+",");
            }
            System.out.println();
            initialState = traverseTo(sol.path.get(0));
            System.out.println("Greedy best first agent>> traverse to " + sol.path.get(0).state.agentVertex);
            totalCost = totalCost + sol.path.get(0).cost;
            totalDepth = totalDepth + sol.path.get(0).depth;
            System.out.println("Greedy best first agent>> on goal");
        } else {
            //noop
            System.out.println("Greedy best first agent>> no-op");
            noop();
        }
    }

    public static State traverseTo(Node n) {
        return n.state;
    }

    public static void noop() {
    }

//returns Solution object with path, cutoff and failure
    public static Solution greedyBestFirstSearch() {
        Solution sol = new Solution();
        ArrayList<State> closed = new ArrayList<>();
        PriorityQueue<Node> fringe = new PriorityQueue<>(1, new Comparator<Node>() {
            @Override
            public int compare(Node n0, Node n1) {
                return new Integer((n0.h)).compareTo(n1.h);
            }
        });
        fringe.add(makeInitialNode(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                sol.failure = true;
                return sol;
            }
            Node n = fringe.remove();
            if (goalTest(goalState, n.state)) {
                sol.path = solutionPath(n);
                sol.cutoff = false;
                return sol;
            }
            if (!closed.contains(n.state)) {
                closed.add(n.state);
                fringe.addAll(greedyBestFirstExpand(n));
            }
        }
    }

    public static ArrayList<Node> greedyBestFirstExpand(Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : greedyBestFirstSuccessorFunction(n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.action = asp.action;
            s.depth = n.depth + 1;
            s.cost = n.cost + stepCost(n, s);
            s.h = uniformCostSearch(s.state);
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> greedyBestFirstSuccessorFunction(State s) {
        int currentVertex = s.agentVertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : s.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            } else {
                for (int i = 0; i < s.lockVertices.length; i++) {
                    if ((ov == s.lockVertices[i]) && (s.agentVertex == s.keyVertices[i])) {
                        selectedVertices.add(ov);
                    }
                }
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[s.keyVertices.length];
            for (int i = 0; i < s.keyVertices.length; i++) {
                if (s.keyVertices[i] == s.agentVertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = s.keyVertices[i];
                }
            }
            int[] svsLockVertices = new int[s.lockVertices.length];
            for (int i = 0; i < s.lockVertices.length; i++) {
                if (sv == s.lockVertices[i]) {
                    svsLockVertices[i] = -6;
                } else {
                    svsLockVertices[i] = s.lockVertices[i];
                }
            }
            State ns = new State(svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static int uniformCostSearch(State initialState) {
        ArrayList<Integer> closed = new ArrayList<>();
        PriorityQueue<Node> fringe = new PriorityQueue<>(1, new Comparator<Node>() {
            @Override
            public int compare(Node n0, Node n1) {
                return new Integer((n0.cost)).compareTo(n1.cost);
            }
        });
        fringe.add(makeInitialNode(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                //no solution
                return 100;
            }
            Node n = fringe.remove();
            if (goalTest(goalState, n.state)) {
                //there is a solution
                return n.cost;
            }
            if (!closed.contains(n.state.agentVertex)) {
                closed.add(n.state.agentVertex);
                fringe.addAll(uniformCostExpand(n));
            }
        }
    }

    public static ArrayList<Node> uniformCostExpand(Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : uniformCostSuccessorFunction(n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.action = asp.action;
            s.depth = n.depth + 1;
            s.cost = n.cost + stepCost(n, s);
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> uniformCostSuccessorFunction(State s) {
        int currentVertex = s.agentVertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = otherVertices;
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = s.keyVertices;
            int[] svsLockVertices = s.lockVertices;
            State ns = new State(svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static int stepCost(Node n, Node s) {
        int stepCost = 0;
        if (n != null) {
            for (Edge e : graph.vertexList[n.state.agentVertex].edgeList) {
                int currentVertex = n.state.agentVertex;
                int otherVertex;
                if (currentVertex == e.source) {
                    otherVertex = e.destination;
                } else {
                    otherVertex = e.source;
                }
                if (otherVertex == s.state.agentVertex) {
                    stepCost = e.weight;
                }
            }
        } else {
            stepCost = stepCost + 0;
        }
        return stepCost;
    }

    public static Node makeInitialNode(State s) {
        Node n = new Node();
        n.state = s;
        n.depth = 0;
        n.parentNode = null;
        n.cost = 0;
        n.action = s.agentVertex;
        return n;
    }

    public static boolean goalTest(int goal, State test) {
        return test.agentVertex == goal;
    }

    public static ArrayList<Node> solutionPath(Node n) {
        ArrayList<Node> s = new ArrayList<>();
        do {
            s.add(n);
            n = n.parentNode;
        } while (n != null);
        return s;
    }

    public static void readGraph() throws FileNotFoundException {
        Scanner input;
        Scanner inFile;
        int numberOfVertices;
        int numberOfKeysAndLocks;
        int initialVertex, goalVertex;
        //read file name
        //input = new Scanner(System.in);
        //System.out.print(
          //      "Graph file name: ");
        File file = new File("graph7.txt");
        //Read number of nodes
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        //Read number of keys and locks
        numberOfKeysAndLocks = inFile.nextInt();
        //read edges, weights, keys, locks
        graph = new Graph(numberOfVertices);
        int[] keys = new int[numberOfKeysAndLocks];
        int[] locks = new int[numberOfKeysAndLocks];
        String s;
        if (inFile.next()
                .equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                if (s.equals("L")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        int v;
        int k;
        while (inFile.hasNext()) {
            s = inFile.next();
            if (s.equals("L")) {
                break;
            }
            v = Integer.parseInt(s);
            k = inFile.nextInt();
            keys[k] = v;
        }
        int l;
        while (inFile.hasNext()) {
            v = inFile.nextInt();
            l = inFile.nextInt();
            locks[l] = v;
        }
        //Read initial vertex
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex: ");
        initialVertex = input.nextInt();
        //Read goal vertex
        input = new Scanner(System.in);
        System.out.print(
                "Goal vertex: ");
        goalVertex = input.nextInt();
        initialState = new State(initialVertex, keys, locks);
        goalState = goalVertex;
    }
}
