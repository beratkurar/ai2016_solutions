/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1GreedyBestFirst;

/**
 *
 * @author B
 */

    public  class Edge {
    public int source,destination,weight;
        public Edge(int s, int d, int w) {
		source=s;
		destination=d;
		weight=w;
        
        }
    }
