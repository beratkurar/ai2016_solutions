/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1Part1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 *
 * @author B
 */
public class AIHW1Part1 {

    public static Graph graph;
    public static State initialState1;
    public static int goalState1;
    public static State initialState2;
    public static int goalState2;

    public static void main(String[] args) throws FileNotFoundException {
        //read graph
        readGraph();
        while (true) {
            humanAgent(graph, initialState1, goalState1);
            greedyAgent(graph, initialState2, goalState2);
            initialState1.keyVertices = initialState2.keyVertices;
            initialState1.lockVertices = initialState2.lockVertices;
            if (initialState1.agentVertex == goalState1) {
                System.out.println("Human agent is on goal");
                break;
            }
            if (initialState2.agentVertex == goalState2) {
                System.out.println("Greedy agent is on goal");
                break;
            }
        }
    }

    public static void greedyAgent(Graph g, State initialState, int goalState) {
        //search solution
        Solution sol = greedySearch(initialState, goalState);
        if (!sol.failure) {
            //display solution path
            System.out.print("Greedy agent>> Solution path: ");
            for (Node n : sol.path) {
                System.out.print(n.action);
            }
            System.out.println();
            initialState2 = traverseTo(sol.path.get(sol.path.size() - 2));
            System.out.println("Greedy agent>> traverse to " + sol.path.get(sol.path.size() - 2).state.agentVertex);
            System.out.println();
        } else {
            //noop
            System.out.println("Greedy agent>> no-op");
            System.out.println();
            noop();
        }
    }

    public static State traverseTo(Node n) {
        return n.state;
    }

    public static void noop() {
    }

//returns Solution object with path, cutoff and failure
    public static Solution greedySearch(State initialState, int goalState) {
        Solution sol = new Solution();
        ArrayList<State> closed = new ArrayList<>();
        PriorityQueue<Node> fringe = new PriorityQueue<>(1, new Comparator<Node>() {
            @Override
            public int compare(Node n0, Node n1) {
                return new Integer((n0.cost)).compareTo(n1.cost);
            }
        });
        fringe.add(makeInitialNode(initialState));
        while (true) {
            if (fringe.isEmpty()) {
                sol.failure = true;
                return sol;
            }
            Node n = fringe.remove();
            if (goalTest(goalState, n.state)) {
                sol.path = solutionPath(n);
                sol.cutoff = false;
                return sol;
            }
            if (!closed.contains(n.state)) {
                closed.add(n.state);
                fringe.addAll(greedyExpand(n));
            }
        }
    }

    public static ArrayList<Node> greedyExpand(Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : greedySuccessorFunction(n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.action = asp.action;
            s.depth = n.depth + 1;
            s.cost = n.cost + stepCost(n, s);
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> greedySuccessorFunction(State s) {
        int currentVertex = s.agentVertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : graph.vertexList[currentVertex].edgeList) {
            if (currentVertex == e.source) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<Integer> selectedVertices = new ArrayList<>();
        for (int ov : otherVertices) {
            boolean bool = true;
            for (int i : s.lockVertices) {
                bool = bool && (ov != i);
            }
            if (bool) {
                selectedVertices.add(ov);
            }
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int sv : selectedVertices) {
            int svsAgentVertex = sv;
            int[] svsKeyVertices = new int[s.keyVertices.length];
            for (int i = 0; i < s.keyVertices.length; i++) {
                if (s.keyVertices[i] == s.agentVertex) {
                    svsKeyVertices[i] = svsAgentVertex;
                } else {
                    svsKeyVertices[i] = s.keyVertices[i];
                }
            }
            int[] svsLockVertices = s.lockVertices;
            State ns = new State(svsAgentVertex, svsKeyVertices, svsLockVertices);
            int na = sv;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }

    public static int stepCost(Node n, Node s) {
        int stepCost = 0;
        if (n != null) {
            for (Edge e : graph.vertexList[n.state.agentVertex].edgeList) {
                int currentVertex = n.state.agentVertex;
                int otherVertex;
                if (currentVertex == e.source) {
                    otherVertex = e.destination;
                } else {
                    otherVertex = e.source;
                }
                if (otherVertex == s.state.agentVertex) {
                    stepCost = e.weight;
                }
            }
        } else {
            stepCost = stepCost + 0;
        }
        return stepCost;
    }

    public static Node makeInitialNode(State s) {
        Node n = new Node();
        n.state = s;
        n.depth = 0;
        n.parentNode = null;
        n.cost = 0;
        n.action = s.agentVertex;
        return n;
    }

    public static boolean goalTest(int goal, State test) {
        return test.agentVertex == goal;
    }

    public static ArrayList<Node> solutionPath(Node n) {
        ArrayList<Node> s = new ArrayList<>();
        do {
            s.add(n);
            n = n.parentNode;
        } while (n != null);
        return s;
    }

    public static void readGraph() throws FileNotFoundException {
        Scanner input;
        Scanner inFile;
        int numberOfVertices;
        int numberOfKeysAndLocks;
        int initialVertex1, goalVertex1;
        int initialVertex2, goalVertex2;
        //read file name
        //input = new Scanner(System.in);
        //System.out.print(
        //        "Graph file name: ");
        File file = new File("graph1.txt");
        //Read number of nodes
        inFile = new Scanner(file);
        numberOfVertices = inFile.nextInt();
        //Read number of keys and locks
        numberOfKeysAndLocks = inFile.nextInt();
        //read edges, weights, keys, locks
        graph = new Graph(numberOfVertices);
        int[] keys = new int[numberOfKeysAndLocks];
        int[] locks = new int[numberOfKeysAndLocks];
        String s;
        if (inFile.next()
                .equals("E")) {
            int v1, v2, w;
            while (inFile.hasNext()) {
                s = inFile.next();
                if (s.equals("K")) {
                    break;
                }
                if (s.equals("L")) {
                    break;
                }
                v1 = Integer.parseInt(s);
                v2 = inFile.nextInt();
                w = inFile.nextInt();
                graph.addEdge(v1, v2, w);
            }
        }
        int v;
        int k;
        while (inFile.hasNext()) {
            s = inFile.next();
            if (s.equals("L")) {
                break;
            }
            v = Integer.parseInt(s);
            k = inFile.nextInt();
            keys[k ] = v;
        }
        int l;
        while (inFile.hasNext()) {
            v = inFile.nextInt();
            l = inFile.nextInt();
            locks[l ] = v;
        }
        //Read initial vertex
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex1: ");
        initialVertex1 = input.nextInt();
        input = new Scanner(System.in);
        System.out.print(
                "Initial vertex2: ");
        initialVertex2 = input.nextInt();
        //Read goal vertex
        input = new Scanner(System.in);
        System.out.print(
                "Goal vertex1: ");
        goalVertex1 = input.nextInt();
        System.out.print(
                "Goal vertex2: ");
        goalVertex2 = input.nextInt();
        initialState1 = new State(initialVertex1, keys, locks);
        goalState1 = goalVertex1;
        initialState2 = new State(initialVertex2, keys, locks);
        goalState2 = goalVertex2;
    }

    /////////////////////////Human Agent
    public static void humanAgent(Graph g, State initialState, int goalState) {
        //display world state
        System.out.println("Human agent>> on: " + initialState.agentVertex);
        System.out.print("Human agent>> Key vertices: ");
        for (int i = 0; i < initialState.keyVertices.length; i++) {
            System.out.print(initialState.keyVertices[i]);
        }
        System.out.println();
        System.out.print("Human agent>> Lock vertices: ");
        for (int i = 0; i < initialState.lockVertices.length; i++) {
            System.out.print(initialState.lockVertices[i]);
        }
        System.out.println();
        //ask next action;
        ArrayList<Node> nextNodes = humanExpand(g, makeInitialNode(initialState));
        System.out.println("Human agent>> Next nodes: ");
        for (Node n : nextNodes) {
            System.out.println("Vertex:" + n.state.agentVertex + ", Cost:" + n.cost + " Depth:" + n.depth);
        }
        Scanner input = new Scanner(System.in);
        System.out.print("Human agent>> Next action: ");
        int action = input.nextInt();
        System.out.println();
        //act and update world
        int nextStateAgentVertex = action;
        int[] nextStateKeyVertices = initialState.keyVertices;
        int[] nextStateLockVertices = initialState.lockVertices;
        initialState1 = new State(nextStateAgentVertex, nextStateKeyVertices, nextStateLockVertices);
    }

    public static ArrayList<Node> humanExpand(Graph g, Node n) {
        ArrayList<Node> successors = new ArrayList<>();
        for (ActionStatePair asp : humanSuccessorFunction(g, n.state)) {
            Node s = new Node();
            s.state = asp.state;
            s.parentNode = n;
            s.action = asp.action;
            s.depth = n.depth + 1;
            s.cost = n.cost + stepCost(n, s);
            successors.add(s);
        }
        return successors;
    }

    public static ArrayList<ActionStatePair> humanSuccessorFunction(Graph g, State s) {
        int currentVertex = s.agentVertex;
        int otherVertex;
        ArrayList<Integer> otherVertices = new ArrayList<>();
        for (Edge e : g.vertexList[currentVertex].edgeList) {
            if (e.source == currentVertex) {
                otherVertex = e.destination;
            } else {
                otherVertex = e.source;
            }
            otherVertices.add(otherVertex);
        }
        ArrayList<ActionStatePair> actionStatePairs = new ArrayList<>();
        for (int ov : otherVertices) {
            int ovsAgentVertex = ov;
            int[] ovsKeyVertices = s.keyVertices;
            int[] ovsLockVertices = s.lockVertices;
            State ns = new State(ovsAgentVertex, ovsKeyVertices, ovsLockVertices);
            int na = ov;
            ActionStatePair asp = new ActionStatePair(na, ns);
            actionStatePairs.add(asp);
        }
        return actionStatePairs;
    }
}
