/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1AStar;

import java.util.ArrayList;

/**
 *
 * @author B
 */
public class Solution {
   public  ArrayList<Node> path=new ArrayList<>();
   public boolean failure=false;
   public boolean cutoff=false;
    
    
}
