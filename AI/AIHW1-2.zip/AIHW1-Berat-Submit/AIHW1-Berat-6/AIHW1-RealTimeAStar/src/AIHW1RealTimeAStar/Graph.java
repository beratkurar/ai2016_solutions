/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1RealTimeAStar;

/**
 *
 * @author B
 */
public class Graph {

   Vertex vertexList[];
    int numberOfVertices;

    Graph(int v) {

        numberOfVertices = v;
        vertexList = new Vertex[v];
        for (int i = 0; i < v; i++) {
            vertexList[i] = new Vertex();
        }
    }

    public void addEdge(int s, int d, int w) {
        Edge e = new Edge(s, d, w);
        vertexList[s].edgeList.add(e);
        vertexList[d].edgeList.add(e);
    }

    

}

