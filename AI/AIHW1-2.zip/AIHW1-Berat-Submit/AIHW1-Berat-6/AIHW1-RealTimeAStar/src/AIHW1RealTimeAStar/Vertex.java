/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIHW1RealTimeAStar;

import java.util.ArrayList;

/**
 *
 * @author B
 */
public class Vertex {

       public ArrayList<Edge> edgeList=new ArrayList<>();
       public ArrayList<Integer> keyList=new ArrayList<>();
       public ArrayList<Integer> lockList=new ArrayList<>();

    }
